﻿Projekt do IJA - Klondike Solitaire
Členové týmu a autoři: Václav Dokoupil (xdokou12), Martin Wojaczek (xwojac00)
Popis: Implementace stejnojmenné karetní hry. Umožňuje rozehrát více jak jednu hru, uložit současný stav nebo se vrátit o několik kroků zpět.
