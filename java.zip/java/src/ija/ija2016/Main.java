/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ija.ija2016.proj;

import ija.ija2016.*;
import ija.ija2016.homework1.cardpack.*;
import ija.ija2016.homework2.model.board.*;
import ija.ija2016.homework2.model.cards.*;

import java.io.IOException;


/**
 *
 * @author Vaclav Dokoupil, xdokou12
 */
public class Main {

    public static void main(String [] args)throws IOException{

    	new Okno();

    }
}
